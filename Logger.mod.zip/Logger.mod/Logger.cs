using System;
using System.IO;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using ScrollsModLoader.Interfaces;
using LinFu.AOP.Interfaces;
using Mono.Cecil;
using Mono.Cecil.Cil;
using UnityEngine;

public class Logger : BaseMod, ICommListener
{
	private StreamWriter Log;

	public Logger ()
	{
		Console.WriteLine ("Logger loading");
		try {
			Log = File.CreateText ("network.log");
		} catch (IOException exp) {
			Console.WriteLine (exp);
		}
		Console.WriteLine ("Logger loaded");
	}

	~Logger()
	{
		Log.Flush();
		Log.Close();
	}
	
	#region implemented abstract members of BaseMod
	public override string GetName ()
	{
		return "Logger";
	}
	public override int GetVersion ()
	{
		return 0;
	}
	public override MethodDefinition[] GetHooks (TypeDefinitionCollection scrollsTypes, int version)
	{
		return new MethodDefinition[] { scrollsTypes["Communicator"].Methods.GetMethod("sendRequest", new Type[] {typeof(String)}) };
	}

	public override void Init() {
		App.Communicator.addListener (this);
	}
	public override bool BeforeInvoke (InvocationInfo info, out object returnValue)
	{
		Log.WriteLine ("Client: "+info.Arguments()[0]);
		returnValue = null;
		return false;
	}
	public override void AfterInvoke (InvocationInfo info, ref object returnValue)
	{
		return;
	}
	
	#endregion

	#region ICommListener implementation

	public void handleMessage (Message msg)
	{
		Log.WriteLine ("Server:" +msg.ToString());
	}

	#endregion
}

